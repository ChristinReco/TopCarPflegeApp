
function berechnePreis() {
    const basispreis = parseFloat(document.getElementById("basispreis").value);
    const fahrzeugtyp = document.getElementById("fahrzeugtyp").value;

    if (isNaN(basispreis)) {
        document.getElementById("ergebnis").innerText = "Bitte gib einen gültigen Preis ein.";
        return;
    }

    let gesamtpreis = basispreis;

    if (fahrzeugtyp === "klein") {
        gesamtpreis *= 0.85; // -15%
    } else if (fahrzeugtyp === "gross") {
        gesamtpreis *= 1.17; // +17%
    }

    document.getElementById("ergebnis").innerText = "Gesamtpreis: " + gesamtpreis.toFixed(2) + " €";
}
